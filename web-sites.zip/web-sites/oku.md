# Merhaba Dostum! 👋

### Bu Proje Yn3ox's YouTube Kanalı için Oluşturulan bir Projedir.


**YouTube ・** [Yn3ox](https://www.youtube.com/channel/UCru0cqYPRfERBkQ_uRtcFdw)

**Discord ・** [Yn3ox's Community](https://discord.gg/Skwz8MYYVn)

**AltYapı Sahibi ・** Yn3ox , GweepCreative
